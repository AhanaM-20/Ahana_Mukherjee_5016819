package com.example.bookstoreapi.controller;
import com.example.bookstoreapi.dto.BookDTO;
import com.example.bookstoreapi.mapper.BookMapper;
import com.example.bookstoreapi.model.Book;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.bookstoreapi.exception.BookNotFoundException;
import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/books")
public class BookController {
    private Book book;
    BookDTO bookDTO = BookMapper.INSTANCE.toBookDTO(book);
    private List<Book> books = new ArrayList<>();

    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        book.setId((long) (books.size() + 1));
        books.add(book);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Created");

        return new ResponseEntity<>(book, headers, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException(id));

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Retrieved");

        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        boolean removed = books.removeIf(book -> book.getId().equals(id));
        if (!removed) {
            throw new BookNotFoundException(id);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Deleted");

        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }
}
