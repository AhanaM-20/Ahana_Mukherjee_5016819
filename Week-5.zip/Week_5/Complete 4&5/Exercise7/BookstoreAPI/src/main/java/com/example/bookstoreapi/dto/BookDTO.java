package com.example.bookstoreapi.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;

@Getter
public class BookDTO {
    // Getters and Setters
    private Long id;

    @JsonProperty("book_title")
    private String title;

    private String author;

    @JsonIgnore
    private double price;  // Remove the duplicate definition

    private String isbn;

    // Constructors, Getters, and Setters
    public BookDTO() {}

    public BookDTO(Long id, String title, String author, double price, String isbn) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.price = price;
        this.isbn = isbn;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}
