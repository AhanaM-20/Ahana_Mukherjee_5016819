package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.dto.CustomerDTO;
import com.example.bookstoreapi.model.Customer;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();

    @GetMapping
    public ResponseEntity<List<EntityModel<CustomerDTO>>> getAllCustomers() {
        List<EntityModel<CustomerDTO>> customerResources = customers.stream()
                .map(this::convertToDTOWithLinks)
                .collect(Collectors.toList());

        return new ResponseEntity<>(customerResources, HttpStatus.OK);
    }

    @PostMapping("/register")
    public ResponseEntity<EntityModel<CustomerDTO>> registerCustomer(@Valid @RequestBody Customer customer) {
        customer.setId((long) (customers.size() + 1));
        customers.add(customer);

        CustomerDTO customerDTO = convertToDTOWithLinks(customer).getContent();

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Registered");

        return new ResponseEntity<>(EntityModel.of(customerDTO), headers, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> getCustomerById(@PathVariable Long id) {
        Customer customer = customers.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        EntityModel<CustomerDTO> resource = convertToDTOWithLinks(customer);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Retrieved");

        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> updateCustomer(@PathVariable Long id, @Valid @RequestBody Customer customer) {
        Customer existingCustomer = customers.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        existingCustomer.setName(customer.getName());
        existingCustomer.setEmail(customer.getEmail());
        existingCustomer.setPassword(customer.getPassword());

        EntityModel<CustomerDTO> updatedResource = convertToDTOWithLinks(existingCustomer);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Updated");

        return new ResponseEntity<>(updatedResource, headers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        boolean removed = customers.removeIf(customer -> customer.getId().equals(id));
        if (!removed) {
            throw new RuntimeException("Customer not found");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Deleted");

        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }

    private EntityModel<CustomerDTO> convertToDTOWithLinks(Customer customer) {
        CustomerDTO customerDTO = new CustomerDTO(customer.getId(), customer.getName(), customer.getEmail(), ""); // Assuming address isn't in the model
        EntityModel<CustomerDTO> resource = EntityModel.of(customerDTO);

        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getCustomerById(customer.getId())).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getAllCustomers()).withRel("all-customers"));

        return resource;
    }
}
