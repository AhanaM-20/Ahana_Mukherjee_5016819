package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        // Implement user authentication here (e.g., check username and password)
        return jwtUtil.generateToken(username);
    }
}
