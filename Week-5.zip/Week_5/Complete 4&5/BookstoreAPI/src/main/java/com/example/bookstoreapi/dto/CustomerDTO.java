package com.example.bookstoreapi.dto;

import org.springframework.hateoas.RepresentationModel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDTO extends RepresentationModel<CustomerDTO> {

    private Long id;
    private String name;
    private String email;
    private String address;

    // Constructors
    public CustomerDTO() {}

    public CustomerDTO(Long id, String name, String email, String address) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.address = address;
    }
}
