package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.dto.BookDTO;
import com.example.bookstoreapi.mapper.BookMapper;
import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.exception.BookNotFoundException;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {
    private List<Book> books = new ArrayList<>();

    @PostMapping
    public ResponseEntity<EntityModel<BookDTO>> createBook(@Valid @RequestBody Book book) {
        book.setId((long) (books.size() + 1));
        books.add(book);

        BookDTO bookDTO = BookMapper.INSTANCE.toBookDTO(book);

        EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(book.getId())).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).listBooks()).withRel("all-books"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Created");

        return new ResponseEntity<>(resource, headers, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> getBookById(@PathVariable Long id) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException(id));

        BookDTO bookDTO = BookMapper.INSTANCE.toBookDTO(book);

        EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id)).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).listBooks()).withRel("all-books"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Retrieved");

        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<EntityModel<BookDTO>>> listBooks() {
        List<EntityModel<BookDTO>> bookResources = books.stream()
                .map(book -> {
                    BookDTO bookDTO = BookMapper.INSTANCE.toBookDTO(book);
                    EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
                    resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(book.getId())).withSelfRel());
                    return resource;
                })
                .collect(Collectors.toList());

        return new ResponseEntity<>(bookResources, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> updateBook(@PathVariable Long id, @Valid @RequestBody Book book) {
        Book existingBook = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException(id));

        existingBook.setTitle(book.getTitle());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setPrice(book.getPrice());
        existingBook.setIsbn(book.getIsbn());

        BookDTO updatedBookDTO = BookMapper.INSTANCE.toBookDTO(existingBook);

        EntityModel<BookDTO> resource = EntityModel.of(updatedBookDTO);
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id)).withSelfRel());
        resource.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).listBooks()).withRel("all-books"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Updated");

        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        boolean removed = books.removeIf(book -> book.getId().equals(id));
        if (!removed) {
            throw new BookNotFoundException(id);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Deleted");

        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }
}
