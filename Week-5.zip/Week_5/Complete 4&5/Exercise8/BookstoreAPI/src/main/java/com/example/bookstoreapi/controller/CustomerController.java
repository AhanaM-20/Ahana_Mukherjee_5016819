package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Customer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();
    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }
    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(@Valid @RequestBody Customer customer) {
        customer.setId((long) (customers.size() + 1));
        customers.add(customer);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Registered");

        return new ResponseEntity<>(customer, headers, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
        Customer customer = customers.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Retrieved");

        return new ResponseEntity<>(customer, headers, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @Valid @RequestBody Customer customer) {
        Customer existingCustomer = customers.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        existingCustomer.setName(customer.getName());
        existingCustomer.setEmail(customer.getEmail());
        existingCustomer.setPassword(customer.getPassword());

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Updated");

        return new ResponseEntity<>(existingCustomer, headers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        boolean removed = customers.removeIf(customer -> customer.getId().equals(id));
        if (!removed) {
            throw new RuntimeException("Customer not found");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Customer Deleted");

        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }
}