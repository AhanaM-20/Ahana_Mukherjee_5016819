//Exercise - 1
//Step-2 & (Setup & Implementation)
//Inventory Management System
import java.util.*;

class Product {
    private int productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(int productId, String productName, int quantity, double price){
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }
    public int get_productId(){
        return productId;
    }
    public void set_productId(int productId){
        this.productId = productId;
    }

    public String get_productName(){
        return productName;
    }
    public void set_productName(String productName){
        this.productName = productName;
    }

    public int get_quantity(){
        return quantity;
    }
    public void set_quantity(int quantity){
        this.quantity = quantity;
    }

    public double get_price(){
        return price;
    }
    public void set_price(double price){
        this.price = price;
    }

    @Override
    public String toString(){
        return "ProductID :"+ productId + ", Name :" + productName + ", Quantity :" + quantity + ", Price :" + price ;
    }
}

public class Inventory_Management_System{
    private HashMap<Integer, Product> inventory;

    public Inventory_Management_System(){
        this.inventory = new HashMap<>();
    }
    public Product getProduct(int productId){
        return inventory.get(productId);
    }

    public void addProduct(Product product){
        if(inventory.containsKey(product.get_productId())){
            System.out.println("ProductID :"+ product.get_productId()+" already exists!");
        }
        else{
            inventory.put(product.get_productId(), product);
            System.out.println("Product" +  product.get_productId()+ " added successfully!");
        }
    }

    public void updateProduct(int productId, String productName, Integer quantity, Double price){
        Product product = inventory.get(productId);
        if(product != null){
            if(productName != null){
                product.set_productName(productName);
            }
            if(quantity != null){
                product.set_quantity(quantity);
            }
            if(price != null){
                product.set_price(price);
            }
            System.out.println("Product "+ productId+ "deleted!");
        }
        else {
            System.out.println("ProductID not found!");
        }
    }


    public void deleteProduct(int productId){
        if(inventory.containsKey(productId)){
            inventory.remove(productId);
            System.out.println("Product successfully removed!");
        }
        else{
            System.out.println("ProductID not found!");
        }
    }

    public void displayInventory(){
        for(Map.Entry<Integer,Product> entry : inventory.entrySet()){
            System.out.println(entry.getValue());
        }
    }

    public static void main(String[] args) {
        Inventory_Management_System iv = new Inventory_Management_System();
        iv.addProduct(new Product(1, "Wheat", 2, 120));
        iv.addProduct(new Product(2, "Rice", 2, 220));

        iv.updateProduct(1, null, 3, 180.00);
        iv.deleteProduct(2);
        iv.displayInventory();

    }
}