//Exercise-5
// Step - 2 & 3 (Setup & Implementation)
//Task Management System
class Task {
    private int taskId;
    private String taskName;
    private String status;

    public Task(int taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    public int getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task ID: " + taskId + ", Task Name: " + taskName + ", Status: " + status;
    }
}
class Node {
    Task task;
    Node next;

    public Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

public class Task_Management_System {
    private Node head;

    public Task_Management_System() {
        this.head = null;
    }

    // Add a new task to the list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by taskId
    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse and print all tasks in the list
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by taskId
    public boolean deleteTask(int taskId) {
        if (head == null) {
            return false;
        }

        if (head.task.getTaskId() == taskId) {
            head = head.next;
            return true;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.task.getTaskId() == taskId) {
                current.next = current.next.next;
                return true;
            }
            current = current.next;
        }

        return false;
    }

    public static void main(String[] args) {
        Task_Management_System taskList = new Task_Management_System();

        Task task1 = new Task(1, "Task One", "Pending");
        Task task2 = new Task(2, "Task Two", "In Progress");
        Task task3 = new Task(3, "Task Three", "Completed");

        taskList.addTask(task1);
        taskList.addTask(task2);
        taskList.addTask(task3);

        System.out.println("Traverse all tasks:");
        taskList.traverseTasks();

        System.out.println("\nSearch for task with ID 2:");
        Task searchResult = taskList.searchTask(2);
        if (searchResult != null) {
            System.out.println("Task found: " + searchResult);
        } else {
            System.out.println("Task not found");
        }

        System.out.println("\nDelete task with ID 2:");
        boolean deleteResult = taskList.deleteTask(2);
        if (deleteResult) {
            System.out.println("Task deleted successfully");
        } else {
            System.out.println("Task not found");
        }

        System.out.println("\nTraverse all tasks after deletion:");
        taskList.traverseTasks();
    }
}


