// Document.java
interface Document {
    void print();
}

interface WordDocument extends Document {
}
interface PdfDocument extends Document {
}
interface ExcelDocument extends Document {
}



class WordDocumentExmpl implements WordDocument {
    @Override
    public void print() {
        System.out.println("Printing a Word document...");
    }
}


class PdfDocumentExmpl implements PdfDocument {
    @Override
    public void print() {
        System.out.println("Printing a PDF document...");
    }
}


class ExcelDocumentExmpl implements ExcelDocument {
    @Override
    public void print() {
        System.out.println("Printing an Excel document...");
    }
}



abstract class DocumentFactory {
    public abstract Document createDocument();
}


class WordDocumentFactory extends DocumentFactory {
    @Override
    public Document createDocument() {
        return new WordDocumentExmpl();
    }
}


class PdfDocumentFactory extends DocumentFactory {
    @Override
    public Document createDocument() {
        return new PdfDocumentExmpl();
    }
}

class ExcelDocumentFactory extends DocumentFactory {
    @Override
    public Document createDocument() {
        return new ExcelDocumentExmpl();
    }
}


public class DocumentFactoryTest {
    public static void main(String[] args) {
        // Create a Word document using the Word document factory
        DocumentFactory wordFactory = new WordDocumentFactory();
        Document wordDocument = wordFactory.createDocument();
        wordDocument.print();

        // Create a PDF document using the PDF document factory
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        Document pdfDocument = pdfFactory.createDocument();
        pdfDocument.print();

        // Create an Excel document using the Excel document factory
        DocumentFactory excelFactory = new ExcelDocumentFactory();
        Document excelDocument = excelFactory.createDocument();
        excelDocument.print();
    }
}
