class Computer {
    private String cpu;
    private int ram;
    private String storage;
    private boolean isWifiEnabled;
    private boolean isBluetoothEnabled;

    // Private constructor to prevent direct instantiation
    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.isWifiEnabled = builder.isWifiEnabled;
        this.isBluetoothEnabled = builder.isBluetoothEnabled;
    }

    // Getters for the attributes
    public String getCpu() {
        return cpu;
    }

    public int getRam() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public boolean isWifiEnabled() {
        return isWifiEnabled;
    }

    public boolean isBluetoothEnabled() {
        return isBluetoothEnabled;
    }

    // Static nested Builder class
    static class Builder {
        private String cpu;
        private int ram;
        private String storage;
        private boolean isWifiEnabled;
        private boolean isBluetoothEnabled;

        public Builder setCPU(String cpu) {
            this.cpu = cpu;
            return this;
        }

        public Builder setRAM(int ram) {
            this.ram = ram;
            return this;
        }

        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder setWifiEnabled(boolean isWifiEnabled) {
            this.isWifiEnabled = isWifiEnabled;
            return this;
        }

        public Builder setBluetoothEnabled(boolean isBluetoothEnabled) {
            this.isBluetoothEnabled = isBluetoothEnabled;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}



public class ComputerBuilderTest {
    public static void main(String[] args) {
        // Create a basic computer configuration
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel Core i3")
                .setRAM(8)
                .setStorage("512 GB SSD")
                .build();

        System.out.println("Basic Computer Configuration:");
        System.out.println("CPU: " + basicComputer.getCpu());
        System.out.println("RAM: " + basicComputer.getRam() + " GB");
        System.out.println("Storage: " + basicComputer.getStorage());
        System.out.println("Wifi: " + (basicComputer.isWifiEnabled() ? "Enabled" : "Disabled"));
        System.out.println("Bluetooth: " + (basicComputer.isBluetoothEnabled() ? "Enabled" : "Disabled"));
        System.out.println();

        // Create a gaming computer configuration
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM(16)
                .setStorage("1 TB SSD")
                .setWifiEnabled(true)
                .setBluetoothEnabled(true)
                .build();

        System.out.println("Gaming Computer Configuration:");
        System.out.println("CPU: " + gamingComputer.getCpu());
        System.out.println("RAM: " + gamingComputer.getRam() + " GB");
        System.out.println("Storage: " + gamingComputer.getStorage());
        System.out.println("Wifi: " + (gamingComputer.isWifiEnabled() ? "Enabled" : "Disabled"));
        System.out.println("Bluetooth: " + (gamingComputer.isBluetoothEnabled() ? "Enabled" : "Disabled"));
    }
}
