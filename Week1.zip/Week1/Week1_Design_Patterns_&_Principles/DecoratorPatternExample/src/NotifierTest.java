interface Notifier {
    void send(String message);
}

class EmailNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("Sending email notification: " + message);
    }
}


abstract class NotifierDecorator implements Notifier {
    protected Notifier notifier;

    public NotifierDecorator(Notifier notifier) {
        this.notifier = notifier;
    }
}


class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        notifier.send(message);
        System.out.println("Sending SMS notification: " + message);
    }
}


class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        notifier.send(message);
        System.out.println("Sending Slack notification: " + message);
    }
}

// NotifierTest.java
public class NotifierTest {
    public static void main(String[] args) {
        // Create an email notifier
        Notifier emailNotifier = new EmailNotifier();

        // Create an SMS notifier decorator
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);

        // Create a Slack notifier decorator
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        // Send a notification using the decorated notifier
        slackNotifier.send("Hello, world!");
    }
}