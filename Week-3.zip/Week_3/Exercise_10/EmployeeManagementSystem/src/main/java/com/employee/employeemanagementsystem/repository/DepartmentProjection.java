package com.employee.employeemanagementsystem.repository;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
