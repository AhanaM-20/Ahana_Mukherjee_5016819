package com.employee.employeemanagementsystem.entity;

import javax.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "departments")
@NamedQueries({
        @NamedQuery(name = "Department.findByNameContaining",
                query = "SELECT d FROM Department d WHERE d.name LIKE %:name%")
})
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
