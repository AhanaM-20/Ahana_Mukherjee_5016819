package com.employee.employeemanagementsystem.repository;

import com.employee.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<EmployeeProjection> findByDepartmentId(Long departmentId);

    List<EmployeeProjection> findByEmailContaining(String email);

    @Query("SELECT e.id AS id, e.name AS name, e.email AS email, " +
            "e.department.id AS departmentId, e.department.name AS departmentName " +
            "FROM Employee e WHERE e.department.name = ?1")
    List<EmployeeProjection> findProjectionByDepartmentName(String departmentName);

    @Query("SELECT e.id AS id, e.name AS name, e.email AS email, " +
            "e.department.id AS departmentId, e.department.name AS departmentName " +
            "FROM Employee e WHERE e.email LIKE %?1%")
    List<EmployeeProjection> findProjectionByEmailPattern(String emailPattern);

    Page<EmployeeProjection> findAllProjectedBy(Pageable pageable);

    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);

    Page<Employee> findEmployeesByEmailPattern(String emailPattern, Pageable pageable);
}
