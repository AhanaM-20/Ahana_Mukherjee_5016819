package com.employee.employeemanagementsystem.entity;

import javax.persistence.*;

import lombok.Getter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import lombok.Data;
import java.time.LocalDateTime;

@Getter
@Data
@Entity
@Table(name = "departments")
@EntityListeners(AuditingEntityListener.class)

@NamedQueries({
        @NamedQuery(name = "Department.findByNameContaining",
                query = "SELECT d FROM Department d WHERE d.name LIKE %:name%")
})
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdDate;

    @LastModifiedDate
    private LocalDateTime lastModifiedDate;

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }
}
