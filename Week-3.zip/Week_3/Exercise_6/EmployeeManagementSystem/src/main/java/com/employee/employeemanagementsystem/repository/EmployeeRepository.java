package com.employee.employeemanagementsystem.repository;

import com.employee.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartmentId(Long departmentId);

    List<Employee> findByEmailContaining(String email);

    Employee findByName(String name);

    // Custom query method using @Query annotation
    @Query("SELECT e FROM Employee e WHERE e.department.name = ?1")
    List<Employee> findByDepartmentName(String departmentName);

    @Query("SELECT e FROM Employee e WHERE e.email LIKE %?1%")
    List<Employee> findEmployeesByEmailPattern(String emailPattern);
    Page<Employee> findAll(Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.department.name = ?1")
    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.email LIKE %?1%")
    Page<Employee> findEmployeesByEmailPattern(String emailPattern, Pageable pageable);
}


