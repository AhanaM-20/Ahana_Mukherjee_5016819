Exercise 4: Functions:-



Scenario 1: Calculate the age of customers for eligibility checks.

o	Question: Write a function CalculateAge that takes a customer's date of birth as input and returns their age in years.



CREATE OR REPLACE FUNCTION CalculateAge(
  p_date_of_birth DATE
)
RETURN NUMBER
AS
  v_age NUMBER;

BEGIN
  v_age := TRUNC(MONTHS_BETWEEN(SYSDATE, p_date_of_birth) / 12);
  RETURN v_age;
END CalculateAge;












Scenario 2: The bank needs to compute the monthly installment for a loan.

o	Question: Write a function CalculateMonthlyInstallment that takes the loan amount, interest rate, and loan duration in years as input and returns the monthly installment amount.



CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment(
  p_loan_amount NUMBER,
  p_interest_rate NUMBER,
  p_loan_duration_years NUMBER
)
RETURN NUMBER
AS
  v_monthly_interest_rate NUMBER;
  v_number_of_months NUMBER;
  v_monthly_installment NUMBER;
BEGIN
  -- Convert interest rate from annual to monthly
  v_monthly_interest_rate := p_interest_rate / 1200;

  -- Calculate the number of months
  v_number_of_months := p_loan_duration_years * 12;

  IF v_monthly_interest_rate = 0 THEN
    v_monthly_installment := p_loan_amount / v_number_of_months;
  ELSE
    -- Calculate the monthly installment using the formula for monthly payments on a fixed-rate loan
    v_monthly_installment := p_loan_amount * v_monthly_interest_rate * 
                             POWER(1 + v_monthly_interest_rate, v_number_of_months) / 
                             (POWER(1 + v_monthly_interest_rate, v_number_of_months) - 1);
  END IF;

  RETURN v_monthly_installment;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error calculating monthly installment: ' || SQLERRM);
    RETURN NULL; 
END CalculateMonthlyInstallment;












Scenario 3: Check if a customer has sufficient balance before making a transaction.

o	Question: Write a function HasSufficientBalance that takes an account ID and an amount as input and returns a boolean indicating whether the account has at least the specified amount.



CREATE OR REPLACE FUNCTION HasSufficientBalance(
  p_account_id NUMBER,
  p_amount NUMBER
)
RETURN BOOLEAN
AS
  v_balance NUMBER;
BEGIN
  SELECT Balance INTO v_balance
  FROM Accounts
  WHERE AccountID = p_account_id;

  -- Check if the balance is sufficient
  IF v_balance >= p_amount THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN FALSE;
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error checking balance: ' || SQLERRM);
    RETURN FALSE;
END HasSufficientBalance;
