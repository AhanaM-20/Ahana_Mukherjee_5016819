Exercise 2: Error Handling:-



Scenario 1: Handle exceptions during fund transfers between accounts.

o	Question: Write a stored procedure SafeTransferFunds that transfers funds between two accounts. Ensure that if any error occurs (e.g., insufficient funds), an appropriate error message is logged and the transaction is rolled back.


CREATE OR REPLACE PROCEDURE SafeTransferFunds(
  p_from_account_id NUMBER,
  p_to_account_id NUMBER,
  p_amount NUMBER
)
AS
  v_from_balance NUMBER;
  v_to_balance NUMBER;
  v_count NUMBER;
  v_insufficient_funds EXCEPTION;
  PRAGMA EXCEPTION_INIT(v_insufficient_funds, -20001);

BEGIN
  -- Check if accounts exist
  BEGIN
    SELECT COUNT(*) INTO v_count FROM Accounts WHERE AccountID = p_from_account_id;
    IF v_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20002, 'Source account does not exist');
    END IF;
    SELECT COUNT(*) INTO v_count FROM Accounts WHERE AccountID = p_to_account_id;
    IF v_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20003, 'Destination account does not exist');
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20006, 'Error checking account existence: ' || SQLERRM);
  END;

  -- Check if accounts are the same
  IF p_from_account_id = p_to_account_id THEN
    RAISE_APPLICATION_ERROR(-20004, 'Cannot transfer funds to the same account');
  END IF;

  -- Check if amount is valid
  IF p_amount <= 0 THEN
    RAISE_APPLICATION_ERROR(-20005, 'Invalid transfer amount');
  END IF;

  -- Retrieve current balances
  SELECT Balance INTO v_from_balance FROM Accounts WHERE AccountID = p_from_account_id;
  SELECT Balance INTO v_to_balance FROM Accounts WHERE AccountID = p_to_account_id;

  -- Check if source account has sufficient funds
  IF v_from_balance < p_amount THEN
    RAISE v_insufficient_funds;
  END IF;


  BEGIN
    UPDATE Accounts SET Balance = Balance - p_amount WHERE AccountID = p_from_account_id;
    UPDATE Accounts SET Balance = Balance + p_amount WHERE AccountID = p_to_account_id;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE_APPLICATION_ERROR(-20000, 'Error during fund transfer: ' || SQLERRM);
  END;

EXCEPTION
  WHEN v_insufficient_funds THEN
    RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in source account');
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20000, 'Unexpected error occurred: ' || SQLERRM);
END SafeTransferFunds;











Scenario 2: Manage errors when updating employee salaries.

o	Question: Write a stored procedure UpdateSalary that increases the salary of an employee by a given percentage. If the employee ID does not exist, handle the exception and log an error message.



CREATE OR REPLACE PROCEDURE UpdateSalary(
  p_employee_id NUMBER,
  p_percentage_increase NUMBER
)
AS
  v_employee_exists NUMBER;
  v_current_salary NUMBER;
  v_new_salary NUMBER;
BEGIN
  -- Check if employee exists
  SELECT COUNT(*) INTO v_employee_exists
  FROM Employees
  WHERE EmployeeID = p_employee_id;

  IF v_employee_exists = 0 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Employee ID ' || p_employee_id || ' does not exist');
  END IF;

  -- Retrieve current salary
  SELECT Salary INTO v_current_salary
  FROM Employees
  WHERE EmployeeID = p_employee_id;

  -- Calculate new salary
  v_new_salary := v_current_salary * (1 + p_percentage_increase / 100);

  -- Update salary
  UPDATE Employees
  SET Salary = v_new_salary
  WHERE EmployeeID = p_employee_id;

  COMMIT;

  DBMS_OUTPUT.PUT_LINE('Salary updated successfully for Employee ID ' || p_employee_id || '. New Salary: ' || v_new_salary);

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    -- Provide a detailed error message
    RAISE_APPLICATION_ERROR(-20000, 'Unexpected error occurred: ' || SQLERRM);
END UpdateSalary;











Scenario 3: Ensure data integrity when adding a new customer.

o	Question: Write a stored procedure AddNewCustomer that inserts a new customer into the Customers table. If a customer with the same ID already exists, handle the exception by logging an error and preventing the insertion.



CREATE OR REPLACE PROCEDURE AddNewCustomer(
  p_customer_id IN NUMBER,
  p_name IN VARCHAR2,
  p_dob IN DATE,
  p_balance IN NUMBER,
  p_last_modified IN DATE
)
AS
  v_customer_exists NUMBER;
BEGIN
  -- Check if customer already exists
  SELECT COUNT(*) INTO v_customer_exists
  FROM Customers
  WHERE CustomerID = p_customer_id;

  IF v_customer_exists > 0 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Customer ID ' || p_customer_id || ' already exists');
  END IF;

  -- Insert new customer
  INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
  VALUES (p_customer_id, p_name, p_dob, p_balance, p_last_modified);

  COMMIT;

  DBMS_OUTPUT.PUT_LINE('Customer added successfully with ID ' || p_customer_id || '.');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
    RAISE;
END AddNewCustomer;

