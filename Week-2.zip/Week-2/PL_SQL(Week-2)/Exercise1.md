Exercise 1: Control Structures:-


Scenario 1: The bank wants to apply a discount to loan interest rates for customers above 60 years old.

o	Question: Write a PL/SQL block that loops through all customers, checks their age, and if they are above 60, apply a 1% discount to their current loan interest rates.


DECLARE
  v_dob DATE;
  v_age NUMBER;
  v_loan_id NUMBER;
  v_interest_rate NUMBER;

BEGIN

  FOR cust_rec IN (SELECT CustomerID, DOB FROM Customers) LOOP
    v_dob := cust_rec.DOB;
    v_age := TRUNC(MONTHS_BETWEEN(SYSDATE, v_dob) / 12);
    IF v_age > 60 THEN
      FOR loan_rec IN (SELECT LoanID, InterestRate FROM Loans WHERE CustomerID = cust_rec.CustomerID) LOOP
        v_loan_id := loan_rec.LoanID;
        v_interest_rate := loan_rec.InterestRate;
        -- Apply the 1% discount to the interest rate
        v_interest_rate := v_interest_rate - 1;
        UPDATE Loans SET InterestRate = v_interest_rate WHERE LoanID = v_loan_id;
      END LOOP;
    END IF;
  END LOOP;

  COMMIT;
END;









Scenario 2: A customer can be promoted to VIP status based on their balance.

o	Question: Write a PL/SQL block that iterates through all customers and sets a flag IsVIP to TRUE for those with a balance over $10,000.



SELECT CustomerID, Balance, IsVIP FROM Customers WHERE IsVIP = 'Y';


BEGIN
    FOR cust_rec IN (SELECT CustomerID, Balance FROM Customers) LOOP
        IF cust_rec.Balance > 10000 THEN
            -- Update IsVIP flag to 'Y'
            UPDATE Customers
            SET IsVIP = 'Y'
            WHERE CustomerID = cust_rec.CustomerID;
            DBMS_OUTPUT.PUT_LINE('Customer ID ' || cust_rec.CustomerID || ' is now a VIP.');
        END IF;
    END LOOP;
    COMMIT;
END;












Scenario 3: The bank wants to send reminders to customers whose loans are due within the next 30 days.

o	Question: Write a PL/SQL block that fetches all loans due in the next 30 days and prints a reminder message for each customer.



DECLARE
  v_loan_id NUMBER;
  v_customer_name VARCHAR2(50);
  v_due_date DATE;
  v_days_left NUMBER;

BEGIN
  FOR cur_loan IN (
    SELECT LoanID, CustomerID, EndDate AS DueDate
    FROM Loans
    WHERE EndDate BETWEEN SYSDATE AND SYSDATE + 30
  ) LOOP
    v_loan_id := cur_loan.LoanID;
    v_due_date := cur_loan.DueDate;
    v_days_left := v_due_date - SYSDATE;
    -- Print reminder message
    DBMS_OUTPUT.PUT_LINE('Reminder: Loan ID ' || v_loan_id || ' for customer ' || v_customer_name || ' is due in ' || v_days_left || ' days.');
  END LOOP;
END;

