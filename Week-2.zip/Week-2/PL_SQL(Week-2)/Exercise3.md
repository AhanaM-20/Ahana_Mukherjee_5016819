Exercise 3: Stored Procedures:-



Scenario 1: The bank needs to process monthly interest for all savings accounts.

o	Question: Write a stored procedure ProcessMonthlyInterest that calculates and updates the balance of all savings accounts by applying an interest rate of 1% to the current balance.


CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest
AS
  v_interest_rate NUMBER := 0.01;  

BEGIN
  UPDATE Accounts
  SET Balance = Balance * (1 + v_interest_rate)
  WHERE AccountType = 'Savings';
  COMMIT;

  DBMS_OUTPUT.PUT_LINE('Monthly interest applied to all savings accounts.');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    -- Log the error message
    DBMS_OUTPUT.PUT_LINE('Error processing monthly interest: ' || SQLERRM);
    -- Re-raise the error to propagate it
    RAISE;
END ProcessMonthlyInterest;











Scenario 2: The bank wants to implement a bonus scheme for employees based on their performance.

o	Question: Write a stored procedure UpdateEmployeeBonus that updates the salary of employees in a given department by adding a bonus percentage passed as a parameter.



CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus(
  p_department IN VARCHAR2,
  p_bonus_percentage IN NUMBER
)
AS
BEGIN
  UPDATE Employees
  SET Salary = Salary + (Salary * p_bonus_percentage / 100)
  WHERE Department = p_department;
  COMMIT;

  
  DBMS_OUTPUT.PUT_LINE('Bonus of ' || p_bonus_percentage || '% applied to all employees in department ' || p_department || '.');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Error updating employee bonus: ' || SQLERRM);
    RAISE;
END UpdateEmployeeBonus;













Scenario 3: Customers should be able to transfer funds between their accounts.

o	Question: Write a stored procedure TransferFunds that transfers a specified amount from one account to another, checking that the source account has sufficient balance before making the transfer.



CREATE OR REPLACE PROCEDURE TransferFunds(
  p_source_account_id NUMBER,
  p_target_account_id NUMBER,
  p_transfer_amount NUMBER
)
AS
  v_source_balance NUMBER;
  v_target_balance NUMBER;

BEGIN
  SELECT Balance
  INTO v_source_balance
  FROM Accounts
  WHERE AccountID = p_source_account_id;

  IF v_source_balance < p_transfer_amount THEN
    RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance in source account');
  END IF;


  UPDATE Accounts
  SET Balance = Balance - p_transfer_amount
  WHERE AccountID = p_source_account_id;

  UPDATE Accounts
  SET Balance = Balance + p_transfer_amount
  WHERE AccountID = p_target_account_id;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20000, 'Error transferring funds: ' || SQLERRM);
END TransferFunds;